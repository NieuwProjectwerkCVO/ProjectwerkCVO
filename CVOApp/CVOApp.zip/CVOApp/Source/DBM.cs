namespace CVOApp
{
    partial class DBMDataContext
    {
    }
}
